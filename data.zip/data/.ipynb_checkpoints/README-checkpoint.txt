This zip file contains

├── 00-Data Processing and Cleaning.ipynb        # Open first.This is the first part of the analysis.
├── 01-Data Exploration and Visualisation.ipynb  # Second part of the analysis.
├── Data                                         # Data files 
│   ├── input                                    # Input files
│   │   ├── zip                                  # Folder containing all the zip files with London geographies
│   │   └── predictors                           # Census Data
│   │         ├── 2011                           # 2011 Census Data
│   │         ├── 2021                           # 2021 Census Data
│   │         └── Combined
│   └── ...
└── ...

The notebook "00-Data Cleaning and Processing" will cover steps 1 and 2, while the notebook "01-Data Exploration" will cover step 3.